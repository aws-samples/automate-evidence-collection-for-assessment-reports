###*********************************************************
###*  AWS audit manager assesment report generator      *###
###*  version : 1                                       *###
###*********************************************************

## Description

This solution will deploy a AWS Batch job that can be triggered from the AWS Console or scheduled using AWS CloudWatch. In addition to generating a Assessment report, the batch job also creates an excel report containing evidences using AWS Audit Manager (https://aws.amazon.com/audit-manager/) based on the filters applied during template execution. The report once generated also sends a notification sent to the provided/created SNS topic.

## Prerequisites

1. AWS Audit Manager is enabled (https://docs.aws.amazon.com/audit-manager/latest/userguide/setting-up.html).
2. You have already created an assessment(needs 24 hours to collect findings) in AWS Audit Manager (https://docs.aws.amazon.com/audit-manager/latest/userguide/tutorial-for-audit-owners.html).
3. Docker is deployed in your local environment, this would be needed to create the image needed for AWS batch



## Input

# Generic parameters

1. TopicName (String)       : SNS topic Name to which status updates would be passed


# New VPC Details(leave blank if using existing VPC)

2. VpcCidrRange (String)            : CIDR range for the new VPC to be created
3. PublicSubnetCidrRange(String)    : CIDR range for the public subnet
4. PrivateSubnetCidrRange (String)  : CIDR range for the private subnet

# Audit manager assessment details
5. name (String)                    : (required) name of the audit manager assesment for which the report is to be generated
6. filterAutomatic(Boolean)         : (optional) excludes manual evidence from the assesment report, defaults to FALSE.
7. AccountIds(String)               : (optional) comma seperated AWS Accounts ids for which the report is to be generated, defaults to None
8. filterLatest(Boolean)            : (optional) associates only lastest evidences to the assesment report, defaults to True

## Output

1. Assessment Report    : default report provided by AWS AUdit Manager, comprsing of evidences based on the provided filters. If no filters are provided, by this script generates the assessment report with 'ALL' evidences.
2. excel workbook(csv)  : comprises of evidence details based on the provided filters. This ocument post report generation would be generated and uploaded along with the evidences in the S3 bucket specified during the assesment creation. The aim for providing this document to to facilitate easy tabulation and granular filteration of evidence data mapped to the assessment report during the report generation process

Note:- once an assessment is created, Audit Manager continuously collects evidence across the selected resources in 1 or more AWS accounts.
This process rapidly accumulates evidences, hence based on the options the user chooses and the evidences size, the report generation process may take time

## deploying the solution

# Step 1 - Create the infrastructure
1. Open your terminal and use the following command to create a folder to clone the project into, then navigate to that folder. Be sure to replace with your own value : mkdir audit-manager/
2. Clone the project into the folder you just created by using the following command : git clone
3. Log into AWS Console and choose appropriate region
4. Navigate to the CloudFormation console and select Create Stack
5. Choose upload a template and upload the file "auditmanager-report-generator.yaml” from the templates folder and click Next
6. Enter the stackname in the screen in lowercase and fill the parameters. A brief description of all the parameters is provided above
7. Click on create stack. The stack takes about 10~15 mins to run


# Step 2 - Create ECR image
Run exec.sh script. This script will create the container image and upload it to the ECR repository.

1. Open terminal
2. Go to the folder
3. Open exec.sh in a text editor and change the to the one given to the cloudformation stack launched in previous step
set STACK_NAME=<name of your stack>
Run the bash script :
chmod +x exec.sh
./exec.sh

The bash script would create a docker image and upload the image to Amazon Elastic Container Registry and execute the python script to generate the report. The report generation may take anywhere upto 3 hrs depending on the amount of evidence collected

# Step 3 - Subscribe to the SNS topic

1. Navigate to the SNS console 
2. Select Topic to list the available SnS topics in the said region topics
3. select Create subscription
4. select Protocol as Email and enter your email id in Endpoint field
5. finally select Create Subscription

You will recieve an email asking you to confirm the subscription, just click on th link to allow SNS to send notifications to the said email id

## cleanup
1. update the stack name in cleanup.sh
2. execute the script cleanup.sh, this will remove Amazon ECR repository images and the AWS CloudFormation stack that was spun up as part of previous steps.

# Reference links

General troubleshooting guide for assesment report generation failures: https://docs.aws.amazon.com/audit-manager/latest/userguide/assessment-report-issues.html
AWS audit manager user guide : https://docs.aws.amazon.com/audit-manager/latest/userguide/what-is.html